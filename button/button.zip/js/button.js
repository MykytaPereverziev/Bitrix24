//function application(){}

function someFunc(){
    alert(document.getElementById("number").value);
    
}
document.getElementById("btn").onclick = someFunc;

//app = new application();
