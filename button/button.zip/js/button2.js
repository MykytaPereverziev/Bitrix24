

function someFunc(){
    alert(document.getElementById("number").value);
    
}
document.getElementById("btn").onclick = someFunc;

BX24.callMethod(
			"crm.deal.get", 
			{ id: 10 }, 
			function(result) 
			{
				if(result.error())
					console.error(result.error());
				else
					console.dir(result.data());
			}
		);	