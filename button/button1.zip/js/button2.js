var btn = document.getElementById('btn');
btn.addEventListener('click', math);
function math(){
    var sum = document.getElementById('number').value;
    var math = Number(sum) + 100;  
    //return math;  
    console.log(math);




//// curl -X POST <URL> UF_CRM_1568377884376 "128"
// <URL> UF_CRM_1568377900618 "64"

  	var id = 18;
BX24.callMethod(
	"crm.deal.update", 
	{ 
		id: id,
		fields:
		{ 
			"UF_CRM_1568377900618": math, //остаток 
			"UF_CRM_1568377884376": 999 //поле для ввода
		},
		params: { "REGISTER_SONET_EVENT": "Y" }			
	}, 
	function(result) 
	{
		if(result.error())
			console.error(result.error());
		else
		{
			console.info(result.data());						
		}
	}
);
};

/*
function addHistory(){

};

function sendSms(){

};
        */