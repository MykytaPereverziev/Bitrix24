$(document).ready(function () {
    BX24.init(function () {
        app.displayCurrentUser('#user-name');
        });
});

function application () {}

application.prototype.displayCurrentUser = function(selector) {
    BX24.callMethod(
        'user.current',
        {},
        function(result) {
            $(selector).html('Приветствую Вас, ' + result.data().NAME + ' ' + result.data().LAST_NAME + ' в приложении BX24!')
        }
    );
    }

    app = new application();
